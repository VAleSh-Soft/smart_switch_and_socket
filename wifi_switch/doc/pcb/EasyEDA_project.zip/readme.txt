            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the file EasyEDA_project.zip, then open it at the editor, you can save it into a project.


Как использовать：

В редакторе откройте документ через меню: Файл — Открыть — EasyEDA... и выберите файл EasyEDA_project.zip, затем откройте его в редакторе и сохраните в проекте.

